SELECT 
    p.ContestId,
    p.Letter
FROM Problems p
JOIN Sessions s ON s.ContestId = p.ContestId
JOIN Runs r ON r.SessionId = s.SessionId
WHERE r.Accepted = 1
GROUP BY p.ContestId, p.Letter
HAVING COUNT(DISTINCT s.SessionId) = (
    SELECT COUNT(DISTINCT s2.SessionId)
    FROM Sessions s2
    WHERE s2.ContestId = p.ContestId
);
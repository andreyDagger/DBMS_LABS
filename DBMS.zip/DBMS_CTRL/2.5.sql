SELECT t.TeamId
FROM Teams t
WHERE NOT EXISTS (
    SELECT 1
    FROM (
        SELECT DISTINCT s.ContestId, r.Letter
        FROM Runs r
        JOIN Sessions s ON s.SessionId = r.SessionId
        WHERE s.TeamId = :TeamId
          AND r.Accepted = 1
    ) solved_by_target
    WHERE NOT EXISTS (
        SELECT 1
        FROM Runs r2
        JOIN Sessions s2 ON s2.SessionId = r2.SessionId
        WHERE s2.TeamId = t.TeamId
          AND r2.Accepted = 1
          AND s2.ContestId = solved_by_target.ContestId
          AND r2.Letter = solved_by_target.Letter
    )
);
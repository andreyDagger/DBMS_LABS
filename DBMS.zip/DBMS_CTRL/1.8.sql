SELECT DISTINCT
    t.TeamName
FROM Teams t
JOIN Universities u ON t.UnivId = u.UnivId
JOIN Sessions s ON t.TeamId = s.TeamId
JOIN Contests c ON s.ContestId = c.ContestId
WHERE NOT EXISTS (
    SELECT 1
    FROM Sessions s2
    JOIN Runs r ON s2.SessionId = r.SessionId
    WHERE s2.TeamId = t.TeamId
      AND s2.ContestId = s.ContestId
      AND r.Accepted = 1
);
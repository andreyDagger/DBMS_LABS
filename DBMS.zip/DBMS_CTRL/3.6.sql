INSERT INTO Runs (SessionId, Letter, SubmitTime, Accepted)
SELECT
    s.SessionId,
    r.Letter,
    r.SubmitTime + 1,
    1
FROM Runs r
JOIN Sessions s ON s.SessionId = r.SessionId
WHERE s.ContestId = :ContestId
  AND r.Accepted = 0
  AND EXISTS (
      SELECT 1
      FROM Runs r2
      WHERE r2.SessionId = r.SessionId
        AND r2.Letter = r.Letter
        AND r2.Accepted = 0
  )
  AND NOT EXISTS (
      SELECT 1
      FROM Runs r3
      WHERE r3.SessionId = r.SessionId
        AND r3.Letter = r.Letter
        AND r3.Accepted = 1
  );

SELECT 
    s.ContestId,
    t.TeamName,
    r.SubmitTime
FROM Runs r
JOIN Sessions s ON s.SessionId = r.SessionId
JOIN Teams t ON t.TeamId = s.TeamId
WHERE t.UnivId = :UnivId
  AND r.Accepted = 1
  AND r.SubmitTime = (
      SELECT MAX(r2.SubmitTime)
      FROM Runs r2
      JOIN Sessions s2 ON s2.SessionId = r2.SessionId
      WHERE s2.ContestId = s.ContestId
        AND s2.TeamId = t.TeamId
        AND r2.Accepted = 1
  )
ORDER BY s.ContestId, r.SubmitTime DESC;

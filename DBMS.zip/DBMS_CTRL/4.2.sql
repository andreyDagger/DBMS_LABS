SELECT 
    t.TeamId,
    COUNT(DISTINCT r.Letter) AS Solved
FROM Teams t
LEFT JOIN Sessions s ON s.TeamId = t.TeamId
LEFT JOIN Runs r ON r.SessionId = s.SessionId AND r.Accepted = 1
GROUP BY t.TeamId;
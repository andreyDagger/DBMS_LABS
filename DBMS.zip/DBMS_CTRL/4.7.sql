SELECT 
    t.TeamName,
    COUNT(DISTINCT r.Letter) AS Solved,
    SUM(
        CASE 
            WHEN r.Accepted = 1 THEN r.SubmitTime
            ELSE 0 
        END
    ) +
    SUM(
        CASE 
            WHEN r.Accepted = 0 THEN r.SubmitTime
            ELSE 0 
        END
    ) AS Penalty
FROM Runs r
JOIN Sessions s ON s.SessionId = r.SessionId
JOIN Teams t ON t.TeamId = s.TeamId
WHERE s.ContestId = :ContestId
GROUP BY t.TeamName
ORDER BY Penalty, MAX(s.SessionId) DESC;
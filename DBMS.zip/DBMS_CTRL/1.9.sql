SELECT 
    s.SessionId
FROM Sessions s
JOIN Runs r ON r.SessionId = s.SessionId
JOIN Problems p ON p.ContestId = s.ContestId
WHERE s.ContestId = :ContestId
GROUP BY s.SessionId
HAVING COUNT(DISTINCT r.Letter) = (SELECT COUNT(*) FROM Problems p2 WHERE p2.ContestId = s.ContestId);
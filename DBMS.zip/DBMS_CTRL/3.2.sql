DELETE FROM Runs
WHERE SessionId IN (
    SELECT s.SessionId 
    FROM Sessions s inner join Teams t on s.TeamId = t.TeamId
    WHERE t.UnivId = :UnivId
);
SELECT 
    s.SessionId, 
    COUNT(DISTINCT r.Letter) AS Solved
FROM Sessions s
LEFT JOIN Runs r ON s.SessionId = r.SessionId AND r.Accepted = 1
GROUP BY s.SessionId;
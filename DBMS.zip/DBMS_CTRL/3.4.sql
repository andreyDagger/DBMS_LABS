UPDATE Runs
SET Accepted = 1
WHERE RunId IN (
    SELECT r_last.RunId
    FROM Runs r_last
    JOIN Sessions s ON s.SessionId = r_last.SessionId
    JOIN Teams t ON t.TeamId = s.TeamId
    WHERE t.UnivId = :UnivId
      AND r_last.SubmitTime = (
          SELECT MAX(r2.SubmitTime)
          FROM Runs r2
          WHERE r2.SessionId = r_last.SessionId
      )
);
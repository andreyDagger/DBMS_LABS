SELECT 
    t.TeamName
FROM Teams t
JOIN Universities u ON t.UnivId = u.UnivId
WHERE u.UnivName = :UnivName
  AND NOT EXISTS (
      SELECT 1
      FROM Sessions s
      JOIN Runs r ON s.SessionId = r.SessionId
      WHERE s.TeamId = t.TeamId
        AND r.Accepted = 1
  );
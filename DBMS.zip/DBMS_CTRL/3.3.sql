INSERT INTO Sessions (TeamId, ContestId, Start)
SELECT t.TeamId, :ContestId, current_timestamp
FROM Teams t
WHERE NOT EXISTS (
    SELECT 1
    FROM Sessions s
    WHERE s.TeamId = t.TeamId
    AND s.ContestId = :ContestId
);
SELECT p.ProblemName
FROM Problems p
WHERE p.ContestId = :ContestId
  AND NOT EXISTS (
      SELECT 1
      FROM Sessions s
      WHERE s.ContestId = :ContestId
        AND NOT EXISTS (
            SELECT 1
            FROM Runs r
            JOIN Sessions s2 ON s2.SessionId = r.SessionId
            WHERE s2.TeamId = s.TeamId
              AND s2.ContestId = p.ContestId
              AND r.Letter = p.Letter
              AND r.Accepted = 1
        )
  );

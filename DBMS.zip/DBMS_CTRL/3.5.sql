UPDATE Runs
SET Accepted = 1
WHERE RunId IN (
    SELECT r_last.RunId
    FROM Runs r_last
    WHERE r_last.SubmitTime = (
        SELECT MAX(r2.SubmitTime)
        FROM Runs r2
        WHERE r2.SessionId = r_last.SessionId
          AND r2.Letter = r_last.Letter
    )
);
SELECT DISTINCT
    u.UnivName
FROM Universities u
WHERE EXISTS (
    SELECT 1
    FROM Teams t
    WHERE t.UnivId = u.UnivId
      AND NOT EXISTS (
          SELECT 1
          FROM Sessions s
          JOIN Runs r ON s.SessionId = r.SessionId
          WHERE s.TeamId = t.TeamId
            AND r.Accepted = 1
      )
);
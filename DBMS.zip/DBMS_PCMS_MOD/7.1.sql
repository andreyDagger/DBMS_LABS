create view StudentMarks(StudentId, Marks) as
 select Students.StudentId,
 count(Mark)
 from Students left outer join Marks on Students.StudentId = Marks.StudentId
  group by Students.StudentId;
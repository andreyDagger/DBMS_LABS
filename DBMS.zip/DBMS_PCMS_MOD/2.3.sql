delete from Students where Students.StudentId in (select X.StudentId from (
	select Students.StudentId from Students natural join Plan left outer join Marks on Plan.CourseId = Marks.CourseId and Students.StudentId = Marks.StudentId
	where Marks.Mark is null
	group by Students.StudentId
	having count(distinct Plan.CourseId) >= 2) X natural join ClubMembers natural join Clubs where Clubs.ClubName = :ClubName);
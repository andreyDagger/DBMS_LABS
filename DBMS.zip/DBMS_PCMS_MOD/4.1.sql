update Students
 set Marks = (select count(*) from Marks where Marks.StudentId = :StudentId)
 where Students.StudentId = :StudentId;
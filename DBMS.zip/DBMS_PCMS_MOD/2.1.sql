delete from Students where exists(
    select CourseId from Plan where Plan.GroupId = Students.GroupId and CourseId not in (
        select Marks.CourseId from Marks where Marks.StudentId = Students.StudentId
    )
);
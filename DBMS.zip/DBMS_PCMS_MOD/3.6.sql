update Students
set GroupId = coalesce((select GroupId from Groups where GroupName = :GroupName), GroupId)
where GroupId in (select GroupId from Groups where GroupName = :FromGroupName);
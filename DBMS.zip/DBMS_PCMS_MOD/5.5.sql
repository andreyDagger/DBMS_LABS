update Students
 set Debts = (select count(distinct Plan.CourseId) from Plan where Plan.GroupId = Students.GroupId and
not exists(select * from Marks where Marks.CourseId = Plan.CourseId and Marks.StudentId =Students.StudentId))
 where Students.StudentId in (select Students.StudentId from Students natural join Groups where Groups.GroupName = :GroupName) and Students.StudentId in (select ClubMembers.StudentId from ClubMembers);
update Students
set Marks = (select count(*) from Marks where Marks.StudentId = Students.StudentId)
where 1=1;
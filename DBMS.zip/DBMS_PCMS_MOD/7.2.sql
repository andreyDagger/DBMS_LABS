create view AllMarks(StudentId, Marks) as
select Students.StudentId, coalesce(OldMarks.OldMarksCnt, 0) + coalesce(NewMarks.NewMarksCnt, 0)
from Students left outer join (select Marks.StudentId, count(Marks.Mark) as OldMarksCnt
from Marks
group by Marks.StudentId) as OldMarks on Students.StudentId = OldMarks.StudentId left outer join (select NewMarks.StudentId, count(NewMarks.Mark) as NewMarksCnt
from NewMarks
group by NewMarks.StudentId) as NewMarks on Students.StudentId = NewMarks.StudentId;
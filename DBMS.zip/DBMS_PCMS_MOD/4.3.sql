update Students
 set Marks = (select count(*) from Marks where Marks.StudentId = Students.StudentId)
 where Students.StudentId in (select Students.StudentId from Students natural join ClubMembers natural join Clubs where Clubs.ClubName = :ClubName);
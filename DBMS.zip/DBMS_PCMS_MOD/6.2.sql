update Marks
set Mark = coalesce((select NewMarks.Mark from NewMarks where Marks.StudentId = NewMarks.StudentId and Marks.CourseId = NewMarks.CourseId), Marks.Mark);
create view StudentDebts(StudentId, Debts) as
select Students.StudentId, coalesce(X.C, 0)
from Students left outer join
(select Students.StudentId as S, count(distinct Plan.CourseId) as C
from Students natural join Plan left outer join Marks on Plan.CourseId = Marks.CourseId and Students.StudentId = Marks.StudentId
where Marks.Mark is null
group by Students.StudentId) X on Students.StudentId = X.S;
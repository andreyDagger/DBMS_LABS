update Marks
set Mark = coalesce((
select case when NewMarks.Mark > Marks.Mark
then NewMarks.Mark
else Marks.Mark
end from NewMarks where Marks.StudentId = NewMarks.StudentId and Marks.CourseId = NewMarks.CourseId), Marks.Mark);
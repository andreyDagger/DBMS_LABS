select AvgAvgMark, GroupName
from Groups left outer join 
    (
        select GroupId, avg(cast(AvgMarkStudent as real)) as AvgAvgMark from 
        Students natural join
        (select StudentId, avg(cast(Mark as real)) as AvgMarkStudent from Marks group by StudentId) kek1
        group by GroupId
    )  kek3
on Groups.GroupId = kek3.GroupId;
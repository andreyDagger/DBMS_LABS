select StudentId, coalesce(Total, 0) as Total, coalesce(Passed, 0) as Passed, coalesce(Total, 0) - coalesce(Passed, 0) as Failed
    from Students
    left outer join (
        select StudentId as StudentId1, count(distinct CourseId) as Total from
        Students natural join Plan
        group by StudentId 
    ) kek1 on Students.StudentId=kek1.StudentId1
    left outer join (
        select StudentId as StudentId2, count(distinct CourseId) as Passed from
        Marks natural join Plan natural join Students
        group by StudentId 
    ) kek2 on Students.StudentId=kek2.StudentId2;
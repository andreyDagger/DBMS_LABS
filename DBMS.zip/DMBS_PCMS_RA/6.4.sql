select distinct s.StudentId
from Students s
where not exists (
    select p.LecturerId
    from Lecturers l
    natural join Plan p
    where l.LecturerName = :LecturerName
    except
    select p2.LecturerId
    from Marks m
    natural join Plan p2
    where m.StudentId = s.StudentId
);
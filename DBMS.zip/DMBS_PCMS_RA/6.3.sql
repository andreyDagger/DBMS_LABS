select distinct m1.StudentId
from Marks m1
where not exists (
    select p.CourseId
    from Lecturers l
    natural join Plan p
    where l.LecturerName = :LecturerName
    except
    select m2.CourseId
    from Marks m2
    where m2.StudentId = m1.StudentId
);
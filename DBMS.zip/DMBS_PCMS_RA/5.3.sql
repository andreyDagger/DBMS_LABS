select StudentName, CourseName from
(
    select StudentId, CourseId 
    from Plan natural join Courses natural join Students
    except select StudentId, CourseId from (select StudentId, CourseId from Plan natural join Courses natural join Marks
    where Mark = 4 or Mark = 5) kek3
) kek2 natural join Courses natural join Students;
select CourseName, GroupName
from (select CourseId, GroupId from Marks cross join Students except
select CourseId, GroupId
from (select Students.StudentId, CourseId, GroupId
from Marks
cross join Students
except
select StudentId, CourseId, GroupId
from Marks natural join Students) kek1) kek2 natural join Courses natural join Groups;
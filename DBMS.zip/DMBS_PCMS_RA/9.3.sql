select AvgMark, GroupName
from Groups left outer join 
    (
        select GroupId, avg(cast(Mark as real)) as AvgMark from
        Marks natural join Students natural join Groups
        group by GroupId
    )  kek3
on Groups.GroupId = kek3.GroupId;
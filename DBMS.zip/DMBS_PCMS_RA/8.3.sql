select SumMark, GroupName
from Groups left outer join 
    (
        select GroupId, sum(SumMarkStudent) as SumMark from 
        Students natural join
        (select StudentId, sum(Mark) as SumMarkStudent from Marks group by StudentId) kek1
        group by GroupId
    )  kek3
on Groups.GroupId = kek3.GroupId;
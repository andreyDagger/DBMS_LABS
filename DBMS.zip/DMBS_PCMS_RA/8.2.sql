select kek.SumMark as SumMark, StudentName
from Students left outer join (select StudentId, sum(Mark) as SumMark from Marks group by StudentId) kek on Students.StudentId = kek.StudentId;
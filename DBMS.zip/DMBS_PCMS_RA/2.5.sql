select s.StudentId, s.StudentName, g.GroupName
from Students s
natural join Groups g
natural join ClubMembers cm
natural join (
    select ClubId, StudentName as HeadName
    from Clubs
    join Students s_head on ClubStudentHeadId = StudentId
) club_heads
where club_heads.HeadName = :StudentName;
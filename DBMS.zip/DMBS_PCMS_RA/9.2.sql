select AvgMark, StudentName
from Students left outer join (select StudentId, avg(cast(Mark as Real)) as AvgMark from Marks group by StudentId) kek on Students.StudentId = kek.StudentId;